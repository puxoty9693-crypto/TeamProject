using UnityEngine;


[CreateAssetMenu(fileName = "Customer_", menuName = "Data/NPC/Customer")]
public class CustomerData : NPCData
{
    [Header("Customer")]
    [SerializeField] private float basePatience = 30f;

    public float BasePatience => basePatience;


    public enum CustomerType { DineIn, Takeout } //�԰����� �մ�, ����ũ�ƿ� �մ�

    [CreateAssetMenu(fileName = "Customer_", menuName = "Data/Customer")]
    public class CustomerData2 : ScriptableObject
    {
        public CustomerType customerType;
        public Sprite customerImage; // �մ� �̹���

    }
}
