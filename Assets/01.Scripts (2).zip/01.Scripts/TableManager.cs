using UnityEngine;

public class TableManager : MMSingleton<TableManager>
{
    public int GetLevel(string tableId)
        => SaveManager.Instance.CurrentData.GetTableLevel(tableId);

    //Ư�� ���̺� ��ȭ
    public bool UpgradeTable(string tableId) 
    {
        var data = DataManager.Instance.tableUpgrades.Find(t => t.tableId == tableId);
        if (data == null) return false;

        return UpgradeHelper.TryUpgrade(GetLevel(tableId), data.levels,() => SaveManager.Instance.CurrentData.UpgradeTableLevel(tableId));
    }

    //���� ������ �� ���� ���� �ο� ���
    public int GetTotallCapacity()
    {
        int total = 0;
        foreach (var tableData in DataManager.Instance.tableUpgrades)
        {
            int level = SaveManager.Instance.CurrentData.GetTableLevel(tableData.tableId);
            if (level < tableData.levels.Count)
                total += tableData.levels[level].capacity;
        }
        return total;
    }

}
