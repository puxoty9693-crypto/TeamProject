using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class PopupManager : MMSingleton<PopupManager>
{
    [Header("�˾�ĵ������ Dim")]
    [SerializeField] GameObject dim;

    [Header("�˾� ������ �ӵ�")]
    [SerializeField] float animDuration = 0.25f;

    private List<GameObject> openPopups = new();

    public void Open(GameObject popup)
    {
        if (popup == null) return;

        if (!openPopups.Contains(popup))
            openPopups.Add(popup);

        dim.SetActive(true);
        popup.SetActive(true);

        var rect = popup.GetComponent<RectTransform>();
        rect.localScale = Vector3.zero;
        rect.DOScale(1f, animDuration).SetEase(Ease.OutBack); // ��¦ ƨ��� Ŀ��

        var cg = popup.GetComponent<CanvasGroup>();
        if (cg != null)
        {
            cg.alpha = 0f;
            cg.DOFade(1f, animDuration);
        }
    }
    public void Close(GameObject popup)
    {
        if (popup == null)
            return;

        var rect = popup.GetComponent<RectTransform>();
        rect.DOScale(0f, animDuration).SetEase(Ease.InBack)
            .OnComplete(() => {
                popup.SetActive(false);
                openPopups.Remove(popup);
                if (openPopups.Count == 0)
                    dim.SetActive(false);
            });
    }
    public void CloseAll()
    {
        foreach (var p in openPopups)
            p.SetActive(false);

        openPopups.Clear();
        dim.SetActive(false);
    }
}
