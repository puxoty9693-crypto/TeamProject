using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
public class CarriageSlotUI : MonoBehaviour
{
    [Header("�̹���")]
    [SerializeField] Image ingredientImage;
    
    [Header("�ؽ�Ʈ")]
    [SerializeField] TextMeshProUGUI costText;
    [SerializeField] TextMeshProUGUI nameText;
    [SerializeField] TextMeshProUGUI levelText;
    [SerializeField] TextMeshProUGUI statText;
    
    [Header("��ư")]
    [SerializeField] Button actionButton;
    [SerializeField] TextMeshProUGUI actionButtonLabel;

    private Action onActionClicked;
    
    private void Awake()
    {
        actionButton.onClick.AddListener(() => onActionClicked?.Invoke());
    }
    public void ShowLocked(IngredientData data, int unlockCost, Action onUnlock)
    {
        ingredientImage.sprite = data.ingredientImage;
        ingredientImage.color = new Color(0.5f, 0.5f, 0.5f, 1f); // ��Ӱ� ǥ��
        nameText.text = data.ingredientName;
        levelText.text = "���ر�";
        statText.text = "";
        costText.text = $"{GoldFormatter.Format(unlockCost)}G";

        if (actionButtonLabel != null)
            actionButtonLabel.text = "�ر�";

        onActionClicked = onUnlock;
        actionButton.interactable = true;
    }
    public void ShowUnlocked(IngredientData data, int level, int supplyAmount, float supplyInterval, int upgradeCost, bool isMaxLevel, Action onUpgrade)
    {
        ingredientImage.sprite = data.ingredientImage;
        ingredientImage.color = Color.white;

        nameText.text = data.ingredientName;
        levelText.text = $"Lv.{level}";
        statText.text = $"{supplyInterval:0}�ʸ��� {supplyAmount}��";

        if (actionButtonLabel != null) 
            actionButtonLabel.text = "��ȭ";

        onActionClicked = onUpgrade;

        if (isMaxLevel)
        {
           costText.text = "MAX";
           actionButton.image.color = Color.white.WithAlpha(0f);
           actionButtonLabel.text = "";
           actionButton.interactable = false;
        }
        
        else
        {
           costText.text = $"{GoldFormatter.Format(upgradeCost)}G";
           actionButton.interactable = true;
        }
        
    }
}


