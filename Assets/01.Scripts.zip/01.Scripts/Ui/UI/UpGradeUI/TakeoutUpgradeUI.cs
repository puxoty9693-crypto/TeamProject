//using TMPro;
//using UnityEngine;
//using UnityEngine.UI;
//
//public class TakeoutUpgradeUI : MonoBehaviour
//{
//    [SerializeField] TextMeshProUGUI levelText;
//    [SerializeField] TextMeshProUGUI chanceText;   // ���� ����ũ�ƿ� Ȯ��
//    [SerializeField] TextMeshProUGUI costText;
//    [SerializeField] Button upgradeButton;
//
//    private void Awake()
//    {
//        upgradeButton.onClick.AddListener(TryUpgrade);
//    }
//
//    private void OnEnable()
//    {
//        Refresh();
//    }
//
//    private void Refresh()
//    {
//        var levels = DataManager.Instance.takeoutUpgradeData.levels;
//        int level = TakeoutManager.Instance.GetLevel();
//        bool isMaxLevel = level >= levels.Count - 1;
//
//        levelText.text = $"Lv.{level + 1}";
//        chanceText.text = $"{TakeoutManager.Instance.GetCurrentTakeOutChance() * 100f:0}%";
//
//        if (isMaxLevel)
//        {
//            costText.text = "MAX";
//            upgradeButton.interactable = false;
//        }
//        else
//        {
//            costText.text = $"{GoldFormatter.Format(levels[level].upgradeGoldCost)}G";
//            upgradeButton.interactable = true;
//        }
//    }
//
//    private void TryUpgrade()
//    {
//        bool success = TakeoutManager.Instance.Upgrade();
//
//        if (!success)
//        {
//            EventManager.Instance.PostNotification(EventType.OnFeedbackMessage, this, "��尡 �����մϴ�");
//            return;
//        }
//
//        EventManager.Instance.PostNotification(EventType.OnChangeGold, this, SaveManager.Instance.CurrentData.Gold);
//        Refresh();
//    }
//}
