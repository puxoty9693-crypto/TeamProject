using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WorkerUpgradeSlot : MonoBehaviour
{
    [Header("�̸��� �̹��� ���� ���Կ� ���� �߰�")]
     //Image workerImage;
     //TextMeshProUGUI nameText;
    [Header("�ؽ�Ʈ")]
    [SerializeField] TextMeshProUGUI costText;
    [SerializeField] TextMeshProUGUI statText;
    [SerializeField] TextMeshProUGUI levelText;

    [Header("��ư")]
    [SerializeField] Button upgradeButton;

    private event Action OnUpgradeClicked;
    private void Awake()
    {
        upgradeButton.onClick.AddListener(() => OnUpgradeClicked?.Invoke());
    }
    public void UpdateSlot( WorkerUpgradeLevel currentLevel, int levelIndex, bool isMaxLevel, System.Action onUpgrade)
    {
        levelText.text = $"Lv.{levelIndex + 1}";
        statText.text = $"ȿ�� {currentLevel.upgradeValue}����";

        OnUpgradeClicked = onUpgrade;
        if(isMaxLevel)
        {
            costText.text = "Max";
            upgradeButton.image.color = Color.white.WithAlpha(0f);
            upgradeButton.interactable = false;
        }
        else
        {
            costText.text = $"{GoldFormatter.Format(currentLevel.upgradeGoldCost)}G";
            upgradeButton.interactable = true;
        }
    }
}
