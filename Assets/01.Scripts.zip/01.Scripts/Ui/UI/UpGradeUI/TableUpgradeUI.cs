using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TableUpgradeUI : MonoBehaviour
{
    [Header("�ؽ�Ʈ")]
    [SerializeField] TextMeshProUGUI levelText;
    [SerializeField] TextMeshProUGUI tableCountText;
    [SerializeField] TextMeshProUGUI costText;
    
    [Header("��ư")]
    [SerializeField] Button upgradeButton;

    private void Awake()
    {
        upgradeButton.onClick.AddListener(TryUpgrade);
    }

    private void OnEnable()
    {
        Refresh();
    }

    private void Refresh()
    {
        var levels = DataManager.Instance.tableUpgradeData.levels;
        int level = TableManager.Instance.GetLevel();
        bool isMaxLevel = level >= levels.Count - 1;

        levelText.text = $"Lv.{level + 1}";
        tableCountText.text = $"��ġ ���� ���̺� {TableManager.Instance.GetMaxTableCount()}��";

        if (isMaxLevel)
        {
            costText.text = "MAX";
            upgradeButton.interactable = false;
        }
        else
        {
            costText.text = $"{GoldFormatter.Format(levels[level].upgradeGoldCost)}G";
            upgradeButton.interactable = true;
        }
    }

    private void TryUpgrade()
    {
        bool success = TableManager.Instance.Upgrade();

        if (!success)
        {
            EventManager.Instance.PostNotification(EventType.OnFeedbackMessage, this, "��尡 �����մϴ�");
            return;
        }

        EventManager.Instance.PostNotification(EventType.OnChangeGold, this, SaveManager.Instance.CurrentData.Gold);
        EventManager.Instance.PostNotification(EventType.OnCustomerMaxCount, this, TableManager.Instance.GetTotalCapacity());
        EventManager.Instance.PostNotification(EventType.OnHousingChanged, this);
        Refresh();
    }
}