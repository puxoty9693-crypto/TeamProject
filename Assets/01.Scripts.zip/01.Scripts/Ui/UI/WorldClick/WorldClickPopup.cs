using UnityEngine;

public class WorldClickPopup : MonoBehaviour, IClickable
{
    [Header("���� �˾�����")]
    [SerializeField] GameObject workerUpgradePopup;

    public void OnClicked()
    {
        PopupManager.Instance.Open(workerUpgradePopup);
    }
}