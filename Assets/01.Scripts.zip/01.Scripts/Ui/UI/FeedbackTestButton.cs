using UnityEngine;
using UnityEngine.UI;

public class TestFeedbackButton : MonoBehaviour
{
    [SerializeField] Button button;

    private void Awake()
    {
        button.onClick.AddListener(() =>
        {
            EventManager.Instance.PostNotification(EventType.OnFeedbackMessage, this, "��尡 �����մϴ�");
        });
    }
}