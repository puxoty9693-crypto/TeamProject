using UnityEngine;

public class GetGoldEffect : MonoBehaviour
{
    /* ���� ó���ϴ°� �Ʒ� �� �ڵ� �߰� ��Ź�帳�ϴ�.
     * EventManager.Instance.PostNotification(EventType.OnGetGold, this, customer.transform.position);
     */

    [SerializeField] ParticleSystem goldEffect;
    private void OnEnable()
    {
        EventManager.Instance.AddListener(EventType.OnGetGold, PlayGoldEffect);
    }
    public void PlayGoldEffect(Component sender, object param)
    {
        if(param is Vector3 pos)
            goldEffect.transform.position = pos;

        goldEffect.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        goldEffect.Play();
    }
    private void OnDisable()
    {
        if (EventManager.HasInstance)
            EventManager.Instance.RemoveListener(EventType.OnGetGold, PlayGoldEffect);
    }
}
