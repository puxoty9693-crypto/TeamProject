using UnityEngine;
using UnityEngine.UI;
public class PopupCloseButton : MonoBehaviour
{
    [Header("�ش��ư")]
    [SerializeField] Button closeButton;
    [Header("���� �˾�")]
    [SerializeField] GameObject targetPopup;
    private void Awake()
    {
        closeButton.onClick.AddListener(() => PopupManager.Instance.Close(targetPopup));
    }
}
