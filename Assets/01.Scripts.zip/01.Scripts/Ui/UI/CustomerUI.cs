using TMPro;
using UnityEngine;

public class CustomerUI : MonoBehaviour
{
    [Header("������Ʈĵ������ �մ��ؽ�Ʈ")]
    [SerializeField] TextMeshProUGUI customerCount;
    [SerializeField] TextMeshProUGUI customerMaxCount;
    private void OnEnable()
    {
        EventManager.Instance.AddListener(EventType.OnCustomerCount, OnCustomerCount);
        EventManager.Instance.AddListener(EventType.OnCustomerMaxCount, OnCustomerMaxCount);
        customerCount.text = "0";
        customerMaxCount.text = $" {TableManager.Instance.GetTotalCapacity()}";
    }
    private void OnDisable()
    {
        if (EventManager.HasInstance)
            EventManager.Instance.RemoveListener(EventType.OnCustomerCount, OnCustomerCount);
    }
    private void OnCustomerMaxCount(Component sender, object param)
    {
        customerMaxCount.text = $"{(int)param}";
    }
    private void OnCustomerCount(Component sender, object param)
    {
        customerCount.text = $"{(int)param}";
    }
}
