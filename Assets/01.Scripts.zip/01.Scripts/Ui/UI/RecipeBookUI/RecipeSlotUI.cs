using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class RecipeSlotUI : MonoBehaviour
{
    [Header( "�ر����")]
    [SerializeField] Image igredent1Img;
    [SerializeField] GameObject igredent1Dim;
    [SerializeField] Image igredent2Img;
    [SerializeField] GameObject igredent2Dim;

    [Header("�����Ǽ���")]
    [SerializeField] Image foodimg;
    [SerializeField] TextMeshProUGUI foodName;
    [SerializeField] TextMeshProUGUI sellPrice;
    [SerializeField] TextMeshProUGUI unlockCost;
    [SerializeField] TextMeshProUGUI buttonText;
    [SerializeField] Button unlockButton;

    private Action onUnlockClicked;
    private void Awake()
    {
        unlockButton.onClick.AddListener(() => onUnlockClicked?.Invoke());
    }

    public void UpdateRecipeUI(RecipeData data, bool isUnlocked, Action onUnlock)
    {
        foodimg.sprite = data.food.foodImage;
        foodName.text = data.food.foodName;
        sellPrice.text = $"���� : {data.food.sellPrice}G";
        onUnlockClicked = onUnlock;

        var required = data.food.requiredIngredients;

        igredent1Img.sprite = required[0].ingredient.ingredientImage;
        bool ingredient1Unlocked = SaveManager.Instance.CurrentData.IsIngredientUnlocked(required[0].ingredient.ingredientId);
        igredent1Dim.SetActive(!ingredient1Unlocked); // �ر� �� ������ �� �ѱ�

        igredent2Img.sprite = required[1].ingredient.ingredientImage;
        bool ingredient2Unlocked = SaveManager.Instance.CurrentData.IsIngredientUnlocked(required[1].ingredient.ingredientId);
        igredent2Dim.SetActive(!ingredient2Unlocked);

        bool ingredientsReady = ingredient1Unlocked && ingredient2Unlocked;

        if (isUnlocked)
        {
            unlockCost.text = "�ر� �Ϸ�";
            buttonText.text = "";
            unlockButton.image.color = Color.white.WithAlpha(0f);
            unlockButton.interactable = false;
        }
        else if (!ingredientsReady)
        {
            unlockCost.text = "��� ���ر�";
            buttonText.text = "�ر� �Ұ�";
            unlockButton.interactable = false;
        }
        else
        {
            buttonText.text = "�ر� ����";
            unlockCost.text = $"{GoldFormatter.Format(data.unlockGoldCost)}G";
            unlockButton.interactable = true;
        }
    }

}
