using System.Collections.Generic;
using UnityEngine;

public class RecipeBookUI : MonoBehaviour
{
    [Header("�����Ǻ� ������ �ֱ�")]
    [SerializeField] List<RectTransform> pages = new();
    private const int slotsPerPage = 2;

    void OnEnable()
    {
        SetRecipes();   
    }
    public void SetRecipes()
    {
        List<RecipeData> recipes = DataManager.Instance.allRecipes;

        for (int i = 0; i < pages.Count; i++)
        {
            RecipeSlotUI[] slots = pages[i].GetComponentsInChildren<RecipeSlotUI>(true);
            for(int j = 0; j < slots.Length; j++)
            {
                int recipeIndex = i * slotsPerPage + j;

                if(recipeIndex < recipes.Count)
                {
                    slots[j].gameObject.SetActive(true);
                    RefreshSlot(recipes[recipeIndex], slots[j]);
                }
                else
                {
                    slots[j].gameObject.SetActive(false);
                }
            }
        }
    }

    private void RefreshSlot(RecipeData data, RecipeSlotUI slot)
    {
        bool isUnlocked = GameManager.Instance.RecipeUnlockSystem.IsUnlocked(data);
        slot.UpdateRecipeUI(data, isUnlocked, () => TryUnlock(data, slot));
    }
  

    private void TryUnlock(RecipeData data, RecipeSlotUI slot)
    {
        bool success = GameManager.Instance.recipeUnlockController.UnlockRecipe(data);
    
        if (!success)
        {
            EventManager.Instance.PostNotification(EventType.OnFeedbackMessage, this, "��尡 �����մϴ�");
            return;
        }
    
        EventManager.Instance.PostNotification(EventType.OnChangeGold, this, SaveManager.Instance.CurrentData.Gold);
        RefreshSlot(data, slot);
    }
}
