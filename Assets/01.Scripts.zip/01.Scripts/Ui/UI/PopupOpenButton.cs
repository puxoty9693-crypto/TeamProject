using UnityEngine;
using UnityEngine.UI;

public class PopupOpenButton : MonoBehaviour
{
    [Header("�ش��ư")]
    [SerializeField] Button openButton;
    [Header("���� �˾�")]
    [SerializeField] GameObject targetPopup;
    private void Awake()
    {
        openButton.onClick.AddListener(() => PopupManager.Instance.Open(targetPopup));
    }
}
