//��۷� �����ؼ� �̻��
//using TMPro;
//using UnityEngine;
//using UnityEngine.UI;
//
//public class CookingRecipeSlot : MonoBehaviour
//{
//    [Header("������info����")]
//    [SerializeField] CookingRecipeInfo cookingInfo;
//
//    [Header("�ؽ�Ʈ")]
//    [SerializeField] TextMeshProUGUI recipeName;
//
//    [Header("��ư")]
//    [SerializeField] Button selectRecipeButton;
//
//    RecipeData currentRecipe;
//    private void Start()
//    {
//        selectRecipeButton.onClick.AddListener(OnClick);
//    }
//    public void SetRecipe(RecipeData data)
//    {
//        currentRecipe = data;
//        recipeName.text = currentRecipe.recipeName;
//    }
//
//    public void OnClick()
//    {
//        cookingInfo.UpdateCookingInfo(currentRecipe);
//    }
//
//}
