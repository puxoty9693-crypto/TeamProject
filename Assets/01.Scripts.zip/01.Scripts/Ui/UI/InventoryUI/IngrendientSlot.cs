using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class IngrendientSlot : MonoBehaviour
{
    [Header("�ؽ�Ʈ")]
    [SerializeField] TextMeshProUGUI countText;
    [SerializeField] int maxCount = 999;
    
    [Header("�̹���")]
    [SerializeField] Sprite nullimg; // null�̹���
    [SerializeField] Image ingredientImg;

    public void UdateChestSlotUI(IngredientData data, IngredientStock stock)
    {
        if (data != null)
        {
            ingredientImg.sprite = data.ingredientImage;
            if(stock.count < maxCount)
            {
                countText.text = $"{stock.count}��";
                return;
            }
            else
            {
                countText.text = $"{maxCount}��";
                return;
            }
        }

        ingredientImg.sprite = nullimg;
        countText.text = "";
    }
}
