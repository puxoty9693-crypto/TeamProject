using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

public class SoundManager : MMSingleton<SoundManager>
{
    [SerializeField] private AudioSource bgmSource;         // BGM ���� AudioSource (���� 1���� �ʿ�)
    [SerializeField] private float bgmFadeDuration = 1f;     // BGM ��ȯ �� ���̵� �ð�
    [SerializeField] private BgmData bgmData;                // ��Ȳ�� BGM ��� ������
    private BgmType currentBgmType;                          // ���� ��� ���� BGM Ÿ�� (�ߺ� ��� ������)


   // [SerializeField] private AudioSource sfxSourcePrefab;    // SFX ����� ������ (AudioSource�� �پ��ִ� ������Ʈ)
   // [SerializeField] private int sfxPoolSize = 10;           // ���ÿ� ��� ������ SFX ����
   // private List<AudioSource> sfxPool = new List<AudioSource>();

    [Range(0f, 1f)] public float bgmVolume = 1f;
    [Range(0f, 1f)] public float sfxVolume = 1f;

    protected override void Awake()
    {
        base.Awake();
       // InitSfxPool();
    }

    private void Start()
    {
        LoadVolumeSettings();
    }

   // // SFX Ǯ �ʱ�ȭ
   // private void InitSfxPool() 
   // {
   //     for (int i = 0; i < sfxPoolSize; i++) 
   //     {
   //         AudioSource source = Instantiate(sfxSourcePrefab, transform);
   //         source.playOnAwake = false;
   //         sfxPool.Add(source);
   //     }
   // }
   //
   // // Ǯ���� ��� ���� �ƴ� ������ҽ� �ϳ� ã��(������ ���� ������ �� ���)
   // private AudioSource GetAvailableSfxSource() 
   // {
   //     foreach (var source in sfxPool) 
   //     {
   //         if (!source.isPlaying) return source;
   //     }
   //     return sfxPool[0];
   // }

    // BGM(Ÿ������ ���)
    public void  PlayBGM(BgmType type, bool loop = true) 
    {
        if (currentBgmType == type && bgmSource.isPlaying) return;

        BgmEntry entry = bgmData.bgmList.Find(b => b.type == type);
        if (entry == null || entry.clip == null)
        {
            return;
        }

        currentBgmType = type;
        PlayBGM(entry.clip, loop);

    }

    //BGM (Ŭ�� ���� ����)
    public void PlayBGM(AudioClip clip, bool loop = true) 
    {
        if (clip == null) return;
        StopAllCoroutines();
        StartCoroutine(FadeBGM(clip, loop));
    }

    public void StopBGM() 
    {
        bgmSource.Stop();
    }

    private IEnumerator FadeBGM(AudioClip newclip, bool loop = true) 
    {
        //�⺻ �� ���̵� �ƿ�
        float startVolume = bgmSource.volume;
        while (bgmSource.volume > 0f) 
        {
            bgmSource.volume -= startVolume * Time.deltaTime / bgmFadeDuration;
            yield return null;
        }

        //Ŭ�� ��ü
        bgmSource.clip = newclip;
        bgmSource.loop = loop;
        bgmSource.Play();

        //�� �� ���̵� ��
        while (bgmSource.volume < bgmVolume) 
        {
            bgmSource.volume += bgmVolume * Time.deltaTime / bgmFadeDuration;
            yield return null;
        }
        bgmSource.volume = bgmVolume;
    }

    //SFX
//    public void PlaySFX(AudioClip clip) 
//    {
//        if (clip == null) return;
//        AudioSource source = GetAvailableSfxSource();
//        source.clip = clip;
//        source.volume = sfxVolume;
//        source.Play();
//    }

    // ���� ���� UI
    public void SetBgmVolume(float volume) 
    {
        bgmVolume = Mathf.Clamp01(volume);
        bgmSource.volume = bgmVolume;
        SaveVolumeSettings();
    }

   // public void SetSfxVolume(float volume) 
   // {
   //     sfxVolume = Mathf.Clamp01(volume);
   //     SaveVolumeSettings();
   // }

    //���� ����/�ε�
    private void SaveVolumeSettings() 
    {
        SaveManager.Instance.CurrentData.SetBgmVolume(bgmVolume);
        //SaveManager.Instance.CurrentData.SetSfxVolume(sfxVolume);
    }

    private void LoadVolumeSettings() 
    {
        bgmVolume = SaveManager.Instance.CurrentData.BgmVolume;
        //sfxVolume = SaveManager.Instance.CurrentData.SfxVolume;
        bgmSource.volume = bgmVolume;
    }

}
