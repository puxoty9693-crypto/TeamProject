using UnityEngine;
using System;
using System.Collections.Generic;
using UnityEngine.Profiling;
using Random = UnityEngine.Random;

public class QuestManager
{
    private readonly PlayerData playerData;
    private readonly SuddenQuestConfig config;

    private readonly Queue<(float time, int totalGold)> incomeHistory = new Queue<(float, int)>(); // �ֱ� ���� ������ (���� ���, ��� ������ ���� �÷��� �ð�)

    private float playTime;
    private float nextQuestTime;

    private bool isChallengeActive;
    private float challengeTimeRemaining;
    private int challengeStartGold;
    private int challengeGoalGold;

    // ���� ����Ʈ ���� (��ǥ �ݾ�, ���� �ð�)
    public event Action<int, float> OnQuestStarted;

    // ���� ����Ʈ ���� (���� ���� �Ǵ�)
    public event Action<bool> OnQuestEnded;

    // ���� ����
    public event Action<QuestRewardType, float> OnRewardGranted;

    public QuestManager(PlayerData data, SuddenQuestConfig config)
    {
        playerData = data;
        this.config = config;

        ScheduleNextQuest();
    }

    public void Update(float deltaTime)
    {
        playTime += deltaTime;

        RecordIncome();

        if (isChallengeActive)
        {
            UpdateChallenge(deltaTime);
        }
        else if (playTime >= nextQuestTime)
        {
            StartChallenge();
        }
    }

    private void ScheduleNextQuest()
    {
        float interval = UnityEngine.Random.Range(config.minIntervalSeconds, config.maxIntervalSeconds);

        nextQuestTime = playTime + interval;
    }
    
    private void RecordIncome() 
    {
        int currentGold = playerData.Gold;
        incomeHistory.Enqueue((playTime, currentGold));

        while (incomeHistory.Count > 0 && playTime - incomeHistory.Peek().time > config.incomeRefrenceWindowSeconds) 
        {
            incomeHistory.Dequeue();
        }
    }


    private void StartChallenge()
    {
        int currentGold = playerData.Gold;

        // �ֱ� ���� ������ ��� �ʴ� �������� ��ǥ �ݾ� ���
        float oldestTime = incomeHistory.Count > 0 ? incomeHistory.Peek().time : playTime;
        int oldestGold = incomeHistory.Count > 0 ? incomeHistory.Peek().totalGold : currentGold;

        float elapsed = Mathf.Max(playTime - oldestTime, 1f);
        float avgPerSecond = (currentGold - oldestGold) / elapsed;

        challengeGoalGold = Mathf.CeilToInt(avgPerSecond * config.challengeDurationSeconds * config.incomeGoalMultiplier);

        challengeGoalGold = Mathf.Max(challengeGoalGold, 1); // �ּ� ��ǥ 1 ��� �̻�

        challengeStartGold = currentGold;
        challengeTimeRemaining = config.challengeDurationSeconds;
        isChallengeActive = true;

        OnQuestStarted?.Invoke(challengeGoalGold, config.challengeDurationSeconds);
    }

    private void UpdateChallenge(float deltaTime) 
    {
        challengeTimeRemaining -= deltaTime;

        if (challengeTimeRemaining > 0f)
            return;

        int earnGold = playerData.Gold - challengeStartGold;
        bool success = earnGold >= challengeGoalGold;

        isChallengeActive = false;
        OnQuestEnded?.Invoke(success);

        if (success) 
        {
            GrantRandomReward();
        }

        ScheduleNextQuest();
    }

    private void GrantRandomReward() 
    {
        var rewardTypes = (QuestRewardType[])Enum.GetValues(typeof(QuestRewardType));
        var rewardType = rewardTypes[Random.Range(0, rewardTypes.Length)];

        float value = rewardType switch
        {
            QuestRewardType.IncomeBonous => Random.Range(config.incomeBonusPercentMin, config.incomeBonusPercentMax + 1),

            QuestRewardType.IngredientSupplyBuff => config.ingredientSupplyMultiplier[Random.Range(0, config.ingredientSupplyMultiplier.Length)],

            QuestRewardType.FoodProductionBUff => config.foodProductionBonus[Random.Range(0, config.foodProductionBonus.Length)],
            _ => 0f

        };

        OnRewardGranted?.Invoke(rewardType,value);
    }

}


